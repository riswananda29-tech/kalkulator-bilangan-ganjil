KALKULATOR BILANGAN GANJIL - KELOMPOK 2
Versi statis untuk GitHub Pages (tanpa Flask dan tanpa kartu pembayaran).

CARA PUBLISH:
1. Upload file index.html ini ke ROOT repository GitHub (sejajar dengan folder kelompok2_flask_render).
2. Buka repository > Settings > Pages.
3. Pada Build and deployment, pilih Deploy from a branch.
4. Branch: main; Folder: /(root); klik Save.
5. Tunggu GitHub Pages menerbitkan situs. URL biasanya:
   https://riswananda29-tech.github.io/kalkulator-bilangan-ganjil/

File ini mandiri: HTML, CSS, dan JavaScript sudah berada dalam satu file.
